export interface Product {
    name:string,
    _id?:string
}
