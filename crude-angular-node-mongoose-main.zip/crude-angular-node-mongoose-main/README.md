# crude-angular-node-mongoose
- Requisitos -
* npm, nodejs e Angular@CLI

#Baixe os arquivos das pastas Server e Front.
=> Edite o arquivo app.js da pasta server para adicionar seu user e nenha do mongodb.


# Instale ambas aplicações, abrindo cada pasta pelo prompt de comando e execute com o comando 'npm install' em ambas.
