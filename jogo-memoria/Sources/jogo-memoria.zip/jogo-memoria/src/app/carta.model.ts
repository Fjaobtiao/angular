export interface ConjCartas{
    imgId: string;
    status: 'padrao' | 'virada' | 'pareada';
}
