import { Routes } from '@angular/router';
import { AngularcliComponent } from './angularcli.component';

export const AngularcliRoutes: Routes = [
    {
        path: 'angularcli',
        component: AngularcliComponent,
    }
];