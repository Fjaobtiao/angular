import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angularcli',
  templateUrl: './angularcli.component.html',
  styleUrls: ['./angularcli.component.css']
})
export class AngularcliComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
