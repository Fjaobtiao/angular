import { Routes } from '@angular/router';
import { PipesComponent } from './pipes.component';

export const PipesRoutes: Routes = [
    {
        path: 'pipes',
        component: PipesComponent,
    }
];