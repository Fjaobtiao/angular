export * from './pipes.component';
export * from './pipes.module';
