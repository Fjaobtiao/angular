import { Routes } from '@angular/router';
import { DatabindingComponent } from './databinding.component';

export const DatabidingRoutes: Routes = [
    {
        path: 'databiding',
        component: DatabindingComponent,
    }
];