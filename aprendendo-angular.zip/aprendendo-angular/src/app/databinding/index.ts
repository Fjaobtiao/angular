export * from './databinding.component';
export * from './databinding.module';
