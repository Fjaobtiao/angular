export * from './diretivas.component';
export * from './diretivas.module';
