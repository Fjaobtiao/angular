import { Routes } from '@angular/router';
import { DiretivasComponent } from './diretivas.component';

export const DiretivasRoutes: Routes = [
    {
        path: 'diretivas',
        component: DiretivasComponent,
    }
];